import { mkdtemp, realpath, lstat, readFile, mkdir, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { createHash } from "node:crypto";
import { requireValue } from "./config.js";
import { run } from "./process.js";
import { PROFILE_CONTEXT, profileAware } from "./profile.js";

const under = (file, p) => file === p || file.startsWith(`${p.replace(/\/$/, "")}/`);

// An `includes` list, when given, is the whole snapshot: only those paths or
// directory prefixes, then excludes and the built-in credential rules apply.
export function included(file, excludes = [], includes = null) {
  const parts = file.split("/");
  return !parts.some(p => [".git", ".gc-deploy", ".codex", ".agents", ".claude", "node_modules"].includes(p) || p.startsWith(".env") || /\.(key|pem)$/.test(p)) &&
    (!includes || includes.some(p => under(file, p))) &&
    !excludes.some(p => under(file, p));
}

// `profileFiles` (a Map of profile-relative path to bytes, from fetchProfile)
// goes into the snapshot under PROFILE_CONTEXT, every byte of it, outside the
// workspace's own filters; a profile-aware service released without a profile
// gets the directory empty, so its Dockerfile's COPY works either way. The
// workspace itself may not contain the reserved path.
export async function snapshot(root, config, allowDirty = false, profileFiles = null) {
  // The reserved path, on the filesystem: an empty directory, a Git-ignored
  // one, a file or a symlink there would all reach a local `docker build`.
  if (profileAware(config)) {
    const reserved = await lstat(path.join(root, PROFILE_CONTEXT)).catch(err => { if (err.code !== "ENOENT") throw err; });
    requireValue(!reserved, `The workspace contains ${PROFILE_CONTEXT}, which is reserved for the release's profile; remove it`);
  }
  // @ts-expect-error TS-MIGRATE: checkJs infers a destructured parameter's type from its default; optional fields read as missing
  const gitRoot = await run("git", ["rev-parse", "--show-toplevel"], { cwd: root });
  requireValue(await realpath(gitRoot) === await realpath(root), "deploy.json must be at the Git workspace root");
  // @ts-expect-error TS-MIGRATE: checkJs infers a destructured parameter's type from its default; optional fields read as missing
  const commit = await run("git", ["rev-parse", "HEAD"], { cwd: root });
  // Changes to paths the snapshot never ships (e.g. an untracked .claude/) don't
  // make the release dirty. Porcelain lines are "XY path" or "XY from -> to".
  // @ts-expect-error TS-MIGRATE: checkJs infers a destructured parameter's type from its default; optional fields read as missing
  const changes = (await run("git", ["status", "--porcelain", "--untracked-files=all"], { cwd: root }))
    .split("\n")
    .filter(line => line && line.slice(3).split(" -> ").some(file => included(file.replace(/^"|"$/g, ""), config.exclude, config.include)))
    .join("\n");
  requireValue(!changes || allowDirty, "Workspace has uncommitted changes; commit them or pass --allow-dirty");
  // @ts-expect-error TS-MIGRATE: checkJs infers a destructured parameter's type from its default; optional fields read as missing
  const files = [...new Set((await run("git", ["ls-files", "-z", "--cached", "--others", "--exclude-standard"], { cwd: root, raw: true })).split("\0").filter(Boolean))].sort();
  const dir = await mkdtemp(path.join(tmpdir(), "gc-deploy-"));
  const source = path.join(dir, "source");
  await mkdir(source);
  const digest = createHash("sha256");
  const manifest = [];
  try {
    for (const file of files) {
      if (!included(file, config.exclude, config.include)) continue;
      requireValue(!path.isAbsolute(file) && !file.split("/").includes(".."), "Unsafe source path");
      const origin = path.join(root, file);
      const stat = await lstat(origin).catch(err => { if (err.code !== "ENOENT") throw err; });
      if (!stat) continue; // tracked deletion in an explicitly allowed dirty workspace
      requireValue(stat.isFile(), `Source must be a regular file (no symlinks/submodules): ${file}`);
      requireValue(await realpath(origin) === path.join(await realpath(root), file), `Source path traverses a symlink: ${file}`);
      const data = await readFile(origin);
      const mode = stat.mode & 0o111 ? 0o755 : 0o644;
      digest.update(JSON.stringify([file, mode, data.length])).update("\0").update(data);
      const destination = path.join(source, file);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, data, { mode });
      manifest.push(file);
    }
    requireValue(manifest.includes(config.dockerfile), "Dockerfile is missing from the source snapshot");
    requireValue(!profileFiles || profileAware(config), "A profile needs a profile-aware service (profileHealth)");
    if (profileAware(config)) {
      await mkdir(path.join(source, PROFILE_CONTEXT));
      for (const [rel, data] of [...(profileFiles ?? new Map())].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) {
        const file = `${PROFILE_CONTEXT}/${rel}`;
        digest.update(JSON.stringify([file, 0o644, data.length])).update("\0").update(data);
        const destination = path.join(source, file);
        await mkdir(path.dirname(destination), { recursive: true });
        await writeFile(destination, data, { mode: 0o644 });
        manifest.push(file);
      }
    }
    // Submit a prebuilt archive so gcloud cannot apply a second implicit ignore policy.
    // Entries are owned by root: Cloud Build keeps archive ownership, and npm runs
    // a package's scripts as its directory's owner, which cannot write $HOME.
    const archive = path.join(dir, "source.tar.gz");
    await run("tar", ["--owner=0", "--group=0", "--numeric-owner", "-czf", archive, "-C", source, "."]);
    return { dir, archive, sourceHash: digest.digest("hex"), commit, dirty: Boolean(changes), changes, files: manifest };
  } catch (error) {
    await rm(dir, { recursive: true, force: true });
    throw error;
  }
}
